#!/usr/bin/env python
import rospy
import time

from Adafruit_MotorHAT import Adafruit_MotorHAT
from std_msgs.msg import String
from geometry_msgs.msg import Twist

def callback(Twist):
#    rospy.loginfo('left=%s', Twist.linear.z)
#    rospy.loginfo('right=%s', Twist.angular.z)

    if abs(Twist.linear.z) >= 0.01:
        set_speed(1,  Twist.linear.z)
    else:
        set_speed(1,  0)

    if abs(Twist.angular.z) >= 0.01:
        set_speed(2,  Twist.angular.z)

    else:
        set_speed(2,  0)

# stops all motors
def all_stop():
    motor_left.setSpeed(0)
    motor_right.setSpeed(0)

    motor_left.run(Adafruit_MotorHAT.RELEASE)
    motor_right.run(Adafruit_MotorHAT.RELEASE)

# sets motor speed between [-1.0, 1.0]
def set_speed(motor_ID, value):
	max_pwm = 120.0
	speed = int(min(max(abs(value * max_pwm), 0), max_pwm))

	if motor_ID == 1:
		motor = motor_left
	elif motor_ID == 2:
		motor = motor_right
	else:
		rospy.logerror('set_speed(%d, %f) -> invalid motor_ID=%d', motor_ID, value, motor_ID)
		return
	motor.setSpeed(speed)

	if value > 0:
		motor.run(Adafruit_MotorHAT.BACKWARD)
	else:
		motor.run(Adafruit_MotorHAT.FORWARD)

# initialization
if __name__ == '__main__':
    # setup motor controller
    motor_driver = Adafruit_MotorHAT(i2c_bus=1)
    motor_left_ID = 1
    motor_right_ID = 2
    motor_left = motor_driver.getMotor(motor_left_ID)
    motor_right = motor_driver.getMotor(motor_right_ID)

    # stop the motors as precaution
    all_stop()

    # setup ros node
    rospy.init_node('jetbot_motors_twist')

    #subscribe
    rospy.Subscriber('cmd_vel', Twist, callback)

    # start running
    rospy.spin()

    # stop motors before exiting
    all_stop()
