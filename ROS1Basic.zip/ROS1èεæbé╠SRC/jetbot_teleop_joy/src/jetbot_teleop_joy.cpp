#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <sensor_msgs/Joy.h>

geometry_msgs::Twist msg;

void joy_callback(const sensor_msgs::Joy& joy_msg) {
//  print joy_msg.axes[1];
  msg.linear.z = joy_msg.axes[1];
//  msg.linear.y = joy_msg.axes[0];
  msg.angular.z = joy_msg.axes[5];
}

int main(int argc, char** argv) {
  ros::init(argc, argv, "jetbot_teleop_joy");
  ros::NodeHandle n;
  ros::Publisher cmd_pub = n.advertise<geometry_msgs::Twist>("cmd_vel", 1000);

  // subscriibe
  ros::Subscriber joy_sub = n.subscribe("joy", 1000, joy_callback);

  ros::Rate loop_rate(10);
  while (ros::ok()) {
    cmd_pub.publish(msg);
    ros::spinOnce();
    loop_rate.sleep();
  }
  return 0;
}

